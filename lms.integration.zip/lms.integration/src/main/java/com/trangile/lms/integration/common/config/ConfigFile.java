package com.trangile.lms.integration.common.config;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.context.annotation.Configuration;

import com.trangile.lms.integration.Application;
import com.trangile.lms.integration.common.util.JsonUtils;
import com.trangile.lms.integration.model.CorporateLocationMapping;
import com.trangile.lms.integration.model.CorporateSetting;

@Configuration
public class ConfigFile {

	
	
	public String readCorporateSetting(String serviceCode, String serviceType){
		try {
			ClassLoader classLoader = Application.class.getClassLoader();
	    File file = new File(classLoader.getResource("CorporateSetting.json").getFile());
	    JSONParser jsonParser = new JSONParser();
	    String settingValue = null;
			
	        List<CorporateSetting> corporateSettingList;
	        if(file.exists()) {
				System.out.println("file exists-----------------------");
				JSONArray jsonArray = (JSONArray) jsonParser.parse(new FileReader(file));
				System.out.println("jsonArray ====="+jsonArray.toJSONString());
				corporateSettingList = new ArrayList<CorporateSetting>();
				corporateSettingList = JsonUtils.parse2List(jsonArray.toString(), CorporateSetting.class);
				System.out.println("corporateSetting==="+corporateSettingList);
				System.out.println("corporateSetting size==="+corporateSettingList.size());
				for(CorporateSetting settingObj:corporateSettingList) {
					if(settingObj.getServiceCode().equals(serviceCode)  && settingObj.getSettingType().equals(serviceType)) {
						settingValue = settingObj.getSettingValue();
						return settingValue;
					}
				}
			return settingValue;
			}
	        
		}catch (FileNotFoundException e) {
	        e.printStackTrace();
	  } catch (IOException e) {
	     e.printStackTrace();
	  } catch (ParseException e) {
	     e.printStackTrace();
	  }
		return null;
	}
	
	public String readCorporateLocationMapping(String serviceCode, String locationID){
		try {
			ClassLoader classLoader = Application.class.getClassLoader();
		    File file = new File(classLoader.getResource("CorporateSetting.json").getFile());
		    JSONParser jsonParser = new JSONParser();
		    String configValue;
	        List<CorporateLocationMapping> corporateLocMappingList;
	        if(file.exists()) {
				System.out.println("file exists-----------------------");
				JSONArray jsonArray = (JSONArray) jsonParser.parse(new FileReader(file));
				System.out.println("jsonArray ====="+jsonArray.toJSONString());
				corporateLocMappingList = new ArrayList<CorporateLocationMapping>();
				corporateLocMappingList = JsonUtils.parse2List(jsonArray.toString(), CorporateLocationMapping.class);
				System.out.println("corporateSetting==="+corporateLocMappingList);
				System.out.println("corporateSetting size==="+corporateLocMappingList.size());
				for(CorporateLocationMapping mappingObj:corporateLocMappingList) {
					if(mappingObj.getServiceCode().equals(serviceCode)  && mappingObj.getLocationID().equals(locationID)) {
						configValue = mappingObj.getConfigJson();
						return configValue;
					}
				}
				
			return null;
			}
	        
		}catch (FileNotFoundException e) {
	        e.printStackTrace();
	  } catch (IOException e) {
	     e.printStackTrace();
	  } catch (ParseException e) {
	     e.printStackTrace();
	  }
		return null;
	}
	
}
