package com.trangile.lms.integration;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.util.ResourceUtils;
import com.fasterxml.jackson.databind.deser.impl.JavaUtilCollectionsDeserializers;
import com.trangile.lms.integration.common.util.JsonUtils;
import com.trangile.lms.integration.model.CorporateSetting;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;



@SpringBootApplication
public class Application {
	public static void main(String[] args)  {
		ConfigurableApplicationContext context = SpringApplication.run(Application.class, args);
	//	String accesskey = context.getEnvironment().getProperty("aws.accessKeyId");
//		try {
//			ClassLoader classLoader = Application.class.getClassLoader();
//	        File file = new File(classLoader.getResource("CorporateSetting.json").getFile());
//	        if(file.exists()) {
//				System.out.println("file exists-----------------------");
//				JSONParser jsonParser = new JSONParser();
//				Gson gson = new Gson();
//				JSONArray jsonArray = (JSONArray) jsonParser.parse(new FileReader(file));
//				System.out.println("jsonArray ====="+jsonArray.toJSONString());
//				List<CorporateSetting> corporateSettingList = new ArrayList<CorporateSetting>();
//				corporateSettingList = JsonUtils.parse2List(jsonArray.toString(), CorporateSetting.class);
//				System.out.println("corporateSetting==="+corporateSettingList);
//				System.out.println("corporateSetting size==="+corporateSettingList.size());
//			
//			}
//	        
//		}catch (FileNotFoundException e) {
//            e.printStackTrace();
//      } catch (IOException e) {
//         e.printStackTrace();
//      } catch (ParseException e) {
//         e.printStackTrace();
//      }
		
		
			
	}

	

}
