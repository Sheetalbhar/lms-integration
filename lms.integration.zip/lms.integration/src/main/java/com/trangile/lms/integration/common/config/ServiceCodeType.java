package com.trangile.lms.integration.common.config;

public class ServiceCodeType {
	public final static String CapitalOne = "CapitalOne";
    public final static String CMBCode= "CMB";
    public final static String CMBCard = "CMB";
    public final static String UnionPay = "UnionPay";
    public final static String CITS = "CITS"; 
    public final static String Yuetu = "Yuetu";
    public final static String ChinaMobileHongKong = "ChinaMobileHongKong";
    public final static String AmexGlobal = "AmexGlobal";
    public final static String EGate = "EGate";
    public final static String EBridge = "EBridge";
    public final static String DragonPass = "DragonPass";
    public final static String DragonPassLounge = "DragonPassLounge";
    public final static String DragonPassVisa = "DragonPassVisa";
    public final static String DragonPassPayment = "DragonPassPayment";
    public final static String TianYiHui = "TianYiHui";
    public final static String Ctrip = "Ctrip";
    public final static String SunCar = "SunCar";
    public final static String PlazaCard = "PlazaCard";
    public final static String Evouvher = "Evoucher";
    public final static String LMS3 = "LMS3";

}
