package com.trangile.lms.integration.common.cryptography;

public enum EncryptionType {
	 MD5,
     SHA512,
     SHA256,
     SHA1,
     AES,
     TripleDES,
}
