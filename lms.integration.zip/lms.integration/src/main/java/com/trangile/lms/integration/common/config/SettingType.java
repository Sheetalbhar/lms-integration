package com.trangile.lms.integration.common.config;

public class SettingType {
	public static String Config = "Config";

    public static String Token = "Token";

    public static String PublicKey = "PublicKey";

}
