package com.trangile.lms.integration.common.config;

public class Config {
	 // public static String PlazaWAS =ConfigurationManager.ConnectionStrings["PlazaWAS"].ConnectionString;

      //public static String PlazaWASLog = ConfigurationManager.ConnectionStrings["PlazaWASLog"].ConnectionString;

      public static String JWTKey = "JWT-Token";
}
