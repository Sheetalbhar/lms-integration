package com.trangile.lms.integration.api;

import java.util.List;

public class EvoucherResponseData {
	private List<EvoucherData> evoucherData;

}
