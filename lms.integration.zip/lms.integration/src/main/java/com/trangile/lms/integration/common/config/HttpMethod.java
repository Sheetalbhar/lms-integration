package com.trangile.lms.integration.common.config;

public enum HttpMethod {
			GET,
            POST,
            PUT,
            DELETE,
            HEAD,
            OPTIONS,
            PATCH,
            MERGE
}

