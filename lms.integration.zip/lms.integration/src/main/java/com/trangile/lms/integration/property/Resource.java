package com.trangile.lms.integration.property;

public class Resource {
	 public static final String ParameterError = "Parameter error";
	 public static final String NoLocationIDConfig = "No locationID configuration";
	   public static final String Success = "Success";

}
