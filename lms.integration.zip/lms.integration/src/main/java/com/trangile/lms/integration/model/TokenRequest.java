package com.trangile.lms.integration.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TokenRequest {
	private String appNo;
	private String appKey;

}
