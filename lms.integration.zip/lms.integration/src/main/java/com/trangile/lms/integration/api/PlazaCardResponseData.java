package com.trangile.lms.integration.api;

import java.util.List;

public class PlazaCardResponseData {
	private PlazaCardInfo cardInfo;
	private List<BalanceCheck> balanceChecks;
}
