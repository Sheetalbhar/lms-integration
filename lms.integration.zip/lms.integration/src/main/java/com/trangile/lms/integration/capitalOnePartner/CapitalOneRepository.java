package com.trangile.lms.integration.capitalOnePartner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.trangile.lms.integration.common.config.ServiceCodeType;
import com.trangile.lms.integration.common.config.SettingType;
import com.trangile.lms.integration.common.util.JsonUtils;
import com.trangile.lms.integration.model.TokenResponse;
import com.trangile.lms.integration.service.CorporateService;

@Repository
public class CapitalOneRepository {
	public static String ClientName = "CapitalOne";
	@Autowired
	private CorporateService corporateService;
//	@Autowired
//	TokenResponse tokenResponse;
	@Autowired
	private CapitalOneConfiguration capitalOneConfig;
//	public CapitalOneRepository() {
//		capitalOneConfig = new CapitalOneConfiguration();
//		String settingValue = corporateService.getCorporateSetting(ServiceCodeType.CapitalOne, SettingType.Config);
//		capitalOneConfig = JsonUtils.parse(settingValue, CapitalOneConfiguration.class);
//        System.out.println("config fetched in constructor============"+capitalOneConfig);
//	}

	public String getLoungeID(String locationID) {
		//corporateService = new CorporateServiceImpl();
        String capitalOneLocation = corporateService.getCorporateLocationMapping(ClientName, locationID);
        if (capitalOneLocation !=null )
        {
       	 LoungeConfig loungeConfig = null;
       	 loungeConfig = JsonUtils.parse(capitalOneLocation, LoungeConfig.class);
            return loungeConfig.getLoungeID();
        }
		return null;
	}

	public String getAccessToken() {
		String accesstoken;
        String tokenString=corporateService.getCorporateSetting(ClientName, SettingType.Token);
        System.out.println("tokenString=========="+tokenString);
//        TokenResponse tokenResponse= new TokenResponse();
//        if (tokenString !=null)
//        {
//        	tokenResponse = converToken(tokenString);
//            LocalDate issued = CommonDateUtil.convertDate(tokenResponse.getIssued_at());
//            LocalDate expiryDate = issued.plus(tokenResponse.getExpires_in(),ERA );
//            DateTime ExpireDate = issued.AddSeconds(token.expires_in);
//            if (ExpireDate < DateTime.Now)
//            {
//                String tokenReponse=GetToken();
//                if (String.IsNullOrWhiteSpace(tokenReponse))
//                {
//                    return null;
//                }
//                token = converToken(tokenString);
//                corporateService.UpdateCorporateSetting(ClientName, SettingType.Token, tokenReponse);
//                return token.token_type + " " + token.access_token;
//            }
//            return token.token_type + " " + token.access_token;
//        }
//        else
//        {
//            String tokenReponse = GetToken();
//            if (String.IsNullOrWhiteSpace(tokenReponse))
//            {
//                return null;
//            }
//            token = converToken(tokenReponse);
//            corporateService.AddCorporateSetting(ClientName, SettingType.Token, tokenReponse);
//            return token.token_type + " " + token.access_token;
//        }
		return null;
	}

	private TokenResponse converToken(String tokenString) {
		TokenResponse tokenResponse = new TokenResponse();
        tokenResponse = JsonUtils.parse(tokenString, TokenResponse.class);
        return tokenResponse;
	}

	public String encryptionCardNo(String cardNo, String token) {
		// TODO Auto-generated method stub
		return null;
	}

	public EligibilityResponse eligibility(String token, String encryptionCardNo, String loungeID) {
		// TODO Auto-generated method stub
		return null;
	}

}
