package com.trangile.lms.integration.property;

public class ResponseMsg {
	 public static final String SUCCESS = "success";
	 public static final String NEW_PASSWORD_REQUIRED = "New password required";
	 public static final String USER_LOGIN_ERROR = "User login error";
	 public static final String Success = "success";
	 public static final String Fail = "fail";

}
