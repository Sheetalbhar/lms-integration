package com.trangile.lms.integration.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.trangile.lms.integration.model.CorporateServiceMapping;
import com.trangile.lms.integration.model.CorporateSetting;
import com.trangile.lms.integration.model.OrderPayment;

@Repository
public class CorporateRepository {


}
