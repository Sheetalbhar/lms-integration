package com.trangile.lms.integration.capitalOnePartner;



import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OffersApplied {
	public String offerType;
    public Integer offerCount;

}
