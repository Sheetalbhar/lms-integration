package com.trangile.lms.integration.property;

public class ResponseCode {
	 public static final String SUCCESS = "00000";
	 public static final String CREATE_USER_ERROR = "A0100";
	 public static final String NEW_PASSWORD_REQUIRED = "A0203";
	 public static final String USER_LOGIN_ERROR = "A0200";
	 
	

}
